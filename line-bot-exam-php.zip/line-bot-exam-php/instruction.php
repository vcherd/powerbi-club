<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<link href="js/sitemapstyler.css" rel="stylesheet" type="text/css" media="screen" />
<link href="css/style.css" rel="stylesheet" type="text/css" media="screen" />
<link rel="stylesheet" href="table.css" type="text/css"/>
<script type="text/javascript" src="js/jquery-2.1.1.min.js"></script>
<title>ขั้นตอนการร่วมกิจกรรม</title>
</head>

<style type="text/css">
.center {
  margin-left: auto;
  margin-right: auto;
}
</style>
<body>

<?
	echo "<h6 style='font-size:33px; text-align:center; color:#709898;'>ขั้นตอนการร่วมกิจกรรม</h6>"; 

?><p></p>


<form action="register_act.php" method="post" enctype="multipart/form-data" name="form1" id="form1" onSubmit="return formValidate()" style="text-align:center;" class="center">

			
	<p></p>
 
<div style="padding-top:10px;">
<img src="pic/KPI_CSR_n.png" width="850px"; style="text-align:middle" >

 </div>
 
<div style="padding-top:10px;">
<img src="pic/ilovebcp.png" width="150px"; style="text-align:middle" >
 </div>
 
 
</tbody>  
    <tfoot>  
     <!--   <tr>  
            <th>Rendering engine</th>  
            <th>Browser</th>  
            <th>Platform(s)</th>  
            <th>Engine version</th>  
            <th>CSS grade</th>  
        </tr>  -->
    </tfoot>  
    
    </table>



	
 <script type="text/javascript">
 
setTimeout("call();",0);

function call()
{
 //alert("เพิ่มข้อมูลเรียบร้อยแล้ว");
// window.location='/bcp_csr/mainuser_admin.php';
}
 
 


  
</script>
  
</body>
</html>